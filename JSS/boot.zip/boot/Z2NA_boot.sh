#15-4-2018 MRC-Epid JHZ

for file in test
do
   echo "${file}"
   sed -i 's/Z/NA/g' ${file}_sample.txt 
done
