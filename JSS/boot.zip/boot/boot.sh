#2-7-2013 MRC-Epid JHZ

plink --bfile test --keep test_unique.id --recode --out test_unique
awk '{
  if(NR==1) {
    i=1
    while (getline t < idfile)
    {
      split(t,a,"\t")
      id[i]=a[1]
      name[i]=a[2]
      n[i]=a[3]
      i++
    }
    close(idfile)
    i=1
  }
  two=$2
  for(k=1;k<=n[i];k++)
  {
    $2=two k
    print $0
  }
  i++
}' idfile=test_unique.id test_unique.ped > test_sample.ped
ln -sf test_unique.map test_sample.map	
plink --file test_sample --make-bed --out test_sample

gcta64 --bfile test_sample --maf 0.01 --autosome --thread-num 20 \
       --make-grm-bin --out test_sample 

trait=(x)
for N in 0
do
   M=$(($N+1))
   ops="--grm-bin test_sample --pheno test_sample.txt --mpheno $M --reml --thread-num 15"
   names=test_sample-${trait[$N]}-$1
   gcta64 $ops --out ${names}
done
