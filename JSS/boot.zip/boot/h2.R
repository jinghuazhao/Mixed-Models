#29-4-2015 MRC-Epid JHZ

trait <- read.table("test.phen",header=FALSE,sep=" ")
names(trait) <- c("id1","id","qt")
boot <- read.table("h2.dat",header=FALSE,sep="\t",as.is=TRUE)
names(boot) <- c("iteration","h2","se")
with(boot,summary(h2))
tiff("04-10-2013.tif")
par(mfrow=c(1,2))
with(trait,hist(qt, main="Distribution of quantitative trait"))
with(boot,hist(h2, main="Heritability from 1000 bootstraps"))
dev.off()
